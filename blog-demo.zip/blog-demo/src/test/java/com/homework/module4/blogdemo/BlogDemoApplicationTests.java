package com.homework.module4.blogdemo;

import com.homework.module4.entity.Article;
import com.homework.module4.repository.ArticleRepository;
import com.homework.module4.service.ArticleService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import java.util.List;
import java.util.Optional;

@SpringBootTest
public class BlogDemoApplicationTests {

    @Autowired
    private ArticleRepository articleRepository;
    @Autowired
    private ArticleService articleService;

    @Test
    public void selectArticle() {
        Optional<Article> optional = articleRepository.findById(1);
        if(optional.isPresent()) {
            Article article = optional.get();
            System.out.println(article);
        }
    }

    @Test
    public void testArticleServiceFindAll() {
        List<Article> list = articleService.queryAllArticle();
        System.out.println(list.size());
        list.forEach(article -> System.out.println(article));
    }


    @Test
    public void testArticleFindByPage() {
        Pageable pageable = PageRequest.of(0, 3, Sort.Direction.DESC, "id");
        Page<Article> page = articleRepository.findAll(pageable);
        long total = page.getTotalElements();
        List<Article> list = page.getContent();
        int totalPages = page.getTotalPages();
        System.out.println("total: " + total);
        System.out.println("totalPages: " + totalPages);
        if(list != null && list.size() != 0)
            list.forEach(article -> System.out.println(article));
    }

}
