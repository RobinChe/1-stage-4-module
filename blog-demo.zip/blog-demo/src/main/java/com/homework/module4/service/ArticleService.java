package com.homework.module4.service;

import com.homework.module4.entity.Article;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ArticleService {


    public List<Article> queryAllArticle();

    /**
     * 分页查询数据
     * @param pageable
     * @return
     */
    public Page<Article> queryArticleByPage(Pageable pageable);

}
