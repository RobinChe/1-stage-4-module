package com.homework.module4.repository;

import com.homework.module4.entity.Article;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface ArticleRepository extends JpaRepository<Article, Integer>, PagingAndSortingRepository<Article, Integer> {


}
