package com.homework.module4.controller;

import com.homework.module4.entity.Article;
import com.homework.module4.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/index")
public class IndexController {

    @Autowired
    private ArticleService articleService;

    @GetMapping("")
    public String toIndex(@PageableDefault(value = 2, sort = {"id"}, direction = Sort.Direction.DESC) Pageable pageable, Model model) {
        System.out.println("首页数据分页加载...." + pageable);

        Page<Article> page = articleService.queryArticleByPage(pageable);
        if(page == null)
            throw new RuntimeException("查询页面数据发生异常");
        model.addAttribute("isFirst", page.isFirst());
        model.addAttribute("isLast", page.isLast());

        model.addAttribute("pageSize", page.getSize());
        model.addAttribute("totalPages", page.getTotalPages());
        model.addAttribute("currentPage", page.getNumber());
        model.addAttribute("list", page.getContent());

        return "client/index";
    }

}

