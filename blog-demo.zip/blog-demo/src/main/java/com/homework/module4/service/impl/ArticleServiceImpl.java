package com.homework.module4.service.impl;

import com.homework.module4.entity.Article;
import com.homework.module4.repository.ArticleRepository;
import com.homework.module4.service.ArticleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ArticleServiceImpl implements ArticleService {

    @Autowired
    private ArticleRepository articleRepository;

    @Override
    public List<Article> queryAllArticle() {
        return articleRepository.findAll();
    }

    @Override
    public Page<Article> queryArticleByPage(Pageable pageable) {
        Page<Article> page = articleRepository.findAll(pageable);
        return page;
    }
}
